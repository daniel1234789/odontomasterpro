import { 
  users, modules, userProgress, quizzes, quizAttempts, achievements, userAchievements, studyPlans,
  type User, type InsertUser, type Module, type InsertModule, type UserProgress, type InsertUserProgress,
  type Quiz, type InsertQuiz, type QuizAttempt, type InsertQuizAttempt, type Achievement, type InsertAchievement,
  type UserAchievement, type InsertUserAchievement, type StudyPlan, type InsertStudyPlan
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Module methods
  getModules(): Promise<Module[]>;
  getModule(id: number): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;
  
  // User progress methods
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserProgressByModule(userId: number, moduleId: number): Promise<UserProgress | undefined>;
  updateUserProgress(userId: number, moduleId: number, progress: Partial<UserProgress>): Promise<UserProgress>;
  
  // Quiz methods
  getQuizzesByModule(moduleId: number): Promise<Quiz[]>;
  getRandomQuizzes(count: number): Promise<Quiz[]>;
  getQuiz(id: number): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  
  // Quiz attempt methods
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getUserQuizAttempts(userId: number): Promise<QuizAttempt[]>;
  
  // Achievement methods
  getAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  unlockAchievement(userId: number, achievementId: number): Promise<UserAchievement>;
  
  // Study plan methods
  getUserStudyPlans(userId: number): Promise<StudyPlan[]>;
  createStudyPlan(plan: InsertStudyPlan): Promise<StudyPlan>;
  updateStudyPlan(id: number, updates: Partial<StudyPlan>): Promise<StudyPlan | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private modules: Map<number, Module> = new Map();
  private userProgress: Map<string, UserProgress> = new Map(); // key: userId-moduleId
  private quizzes: Map<number, Quiz> = new Map();
  private quizAttempts: Map<number, QuizAttempt> = new Map();
  private achievements: Map<number, Achievement> = new Map();
  private userAchievements: Map<string, UserAchievement> = new Map(); // key: userId-achievementId
  private studyPlans: Map<number, StudyPlan> = new Map();
  
  private currentUserId = 1;
  private currentModuleId = 1;
  private currentQuizId = 1;
  private currentQuizAttemptId = 1;
  private currentAchievementId = 1;
  private currentUserAchievementId = 1;
  private currentStudyPlanId = 1;
  private currentUserProgressId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Create default user
    const defaultUser: User = {
      id: this.currentUserId++,
      username: "joao.silva",
      email: "joao.silva@example.com",
      password: "password123",
      name: "Dr. João Silva",
      mode: "student",
      language: "pt",
      level: "Expert",
      streakDays: 7,
      totalPoints: 2850,
      createdAt: new Date(),
    };
    this.users.set(defaultUser.id, defaultUser);

    // Initialize modules
    const moduleData = [
      { name: "Exodontia", description: "Técnicas de extração dental", icon: "fas fa-scissors", color: "red", order: 1, totalLessons: 12 },
      { name: "Periodontologia", description: "Doenças periodontais", icon: "fas fa-heartbeat", color: "green", order: 2, totalLessons: 15 },
      { name: "Dentística Restauradora", description: "Restaurações estéticas", icon: "fas fa-tooth", color: "blue", order: 3, totalLessons: 18 },
      { name: "Ortodontia", description: "Correção de maloclusões", icon: "fas fa-smile", color: "purple", order: 4, totalLessons: 20 },
      { name: "Endodontia", description: "Tratamento de canal", icon: "fas fa-syringe", color: "orange", order: 5, totalLessons: 14 },
      { name: "Farmacologia", description: "Medicamentos odontológicos", icon: "fas fa-pills", color: "teal", order: 6, totalLessons: 10 },
      { name: "Esterilização e Biossegurança", description: "Protocolos de segurança", icon: "fas fa-shield-alt", color: "red", order: 7, totalLessons: 8 },
      { name: "Radiologia", description: "Interpretação radiográfica", icon: "fas fa-x-ray", color: "gray", order: 8, totalLessons: 12 },
      { name: "Anatomia Dental", description: "Estruturas dentárias", icon: "fas fa-brain", color: "indigo", order: 9, totalLessons: 16 },
      { name: "Odontopediatria", description: "Odontologia infantil", icon: "fas fa-child", color: "pink", order: 10, totalLessons: 13 },
      { name: "Prótese e Cirurgia Oral", description: "Reabilitação protética", icon: "fas fa-tools", color: "yellow", order: 11, totalLessons: 22 },
      { name: "Atendimento a Pacientes Especiais", description: "Cuidados especializados", icon: "fas fa-wheelchair", color: "purple", order: 12, totalLessons: 9 },
      { name: "Ética e Legislação Odontológica", description: "Aspectos legais", icon: "fas fa-balance-scale", color: "gray", order: 13, totalLessons: 7 }
    ];

    moduleData.forEach(mod => {
      const module: Module = {
        id: this.currentModuleId++,
        ...mod
      };
      this.modules.set(module.id, module);
    });

    // Initialize user progress for some modules
    const progressData = [
      { moduleId: 1, completedLessons: 9, totalLessons: 12, score: 75 }, // Exodontia
      { moduleId: 2, completedLessons: 15, totalLessons: 15, score: 100 }, // Periodontologia
      { moduleId: 3, completedLessons: 4, totalLessons: 18, score: 25 }, // Dentística
      { moduleId: 5, completedLessons: 7, totalLessons: 14, score: 50 }, // Endodontia
      { moduleId: 6, completedLessons: 3, totalLessons: 10, score: 30 }, // Farmacologia
      { moduleId: 8, completedLessons: 5, totalLessons: 12, score: 40 }, // Radiologia
      { moduleId: 9, completedLessons: 16, totalLessons: 16, score: 100 }, // Anatomia
    ];

    progressData.forEach(prog => {
      const progress: UserProgress = {
        id: this.currentUserProgressId++,
        userId: defaultUser.id,
        moduleId: prog.moduleId,
        completedLessons: prog.completedLessons,
        totalLessons: prog.totalLessons,
        score: prog.score,
        lastAccessedAt: new Date(),
      };
      this.userProgress.set(`${defaultUser.id}-${prog.moduleId}`, progress);
    });

    // Initialize achievements
    const achievementData = [
      { name: "Primeiro Quiz", description: "Complete seu primeiro quiz", icon: "fas fa-medal", requirement: "complete_first_quiz", points: 50 },
      { name: "Sequência 7 dias", description: "Estude por 7 dias consecutivos", icon: "fas fa-crown", requirement: "streak_7_days", points: 100 },
      { name: "Especialista em Periodontia", description: "Complete 100% do módulo de Periodontologia", icon: "fas fa-trophy", requirement: "complete_periodontia", points: 200 },
      { name: "Master", description: "Complete todos os módulos", icon: "fas fa-star", requirement: "complete_all_modules", points: 1000 }
    ];

    achievementData.forEach(ach => {
      const achievement: Achievement = {
        id: this.currentAchievementId++,
        ...ach
      };
      this.achievements.set(achievement.id, achievement);
    });

    // Unlock some achievements for default user
    [1, 2, 3].forEach(achievementId => {
      const userAchievement: UserAchievement = {
        id: this.currentUserAchievementId++,
        userId: defaultUser.id,
        achievementId,
        unlockedAt: new Date(),
      };
      this.userAchievements.set(`${defaultUser.id}-${achievementId}`, userAchievement);
    });

    // Initialize sample quizzes
    const sampleQuizzes = [
      {
        moduleId: 2,
        question: "Qual é a principal causa da doença periodontal?",
        options: ["Placa bacteriana", "Cálculo dental", "Trauma oclusal", "Fatores genéticos"],
        correctAnswer: 0,
        explanation: "A placa bacteriana é a principal causa da doença periodontal, pois contém bactérias que produzem toxinas que irritam a gengiva.",
        difficulty: "medium"
      },
      {
        moduleId: 1,
        question: "Qual é a técnica mais segura para extração de terceiros molares inclusos?",
        options: ["Extração com fórceps", "Odontosecção", "Extração simples", "Curetagem"],
        correctAnswer: 1,
        explanation: "A odontosecção é a técnica mais segura para terceiros molares inclusos, pois permite melhor controle e menor trauma aos tecidos.",
        difficulty: "hard"
      }
    ];

    sampleQuizzes.forEach(quiz => {
      const quizItem: Quiz = {
        id: this.currentQuizId++,
        ...quiz
      };
      this.quizzes.set(quizItem.id, quizItem);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(user: InsertUser): Promise<User> {
    const newUser: User = {
      id: this.currentUserId++,
      username: user.username,
      email: user.email,
      password: user.password,
      name: user.name,
      mode: user.mode || "student",
      language: user.language || "pt",
      level: user.level || "Iniciante",
      streakDays: user.streakDays || 0,
      totalPoints: user.totalPoints || 0,
      createdAt: new Date(),
    };
    this.users.set(newUser.id, newUser);
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Module methods
  async getModules(): Promise<Module[]> {
    return Array.from(this.modules.values()).sort((a, b) => a.order - b.order);
  }

  async getModule(id: number): Promise<Module | undefined> {
    return this.modules.get(id);
  }

  async createModule(module: InsertModule): Promise<Module> {
    const newModule: Module = {
      id: this.currentModuleId++,
      name: module.name,
      description: module.description,
      icon: module.icon,
      color: module.color,
      order: module.order,
      totalLessons: module.totalLessons || 0,
    };
    this.modules.set(newModule.id, newModule);
    return newModule;
  }

  // User progress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values())
      .filter(progress => progress.userId === userId);
  }

  async getUserProgressByModule(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    return this.userProgress.get(`${userId}-${moduleId}`);
  }

  async updateUserProgress(userId: number, moduleId: number, updates: Partial<UserProgress>): Promise<UserProgress> {
    const key = `${userId}-${moduleId}`;
    const existing = this.userProgress.get(key);
    
    const progress: UserProgress = {
      id: existing?.id || this.currentUserProgressId++,
      userId,
      moduleId,
      completedLessons: 0,
      totalLessons: 0,
      score: 0,
      lastAccessedAt: new Date(),
      ...existing,
      ...updates,
    };
    
    this.userProgress.set(key, progress);
    return progress;
  }

  // Quiz methods
  async getQuizzesByModule(moduleId: number): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(quiz => quiz.moduleId === moduleId);
  }

  async getRandomQuizzes(count: number): Promise<Quiz[]> {
    const allQuizzes = Array.from(this.quizzes.values());
    const shuffled = allQuizzes.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }

  async getQuiz(id: number): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const newQuiz: Quiz = {
      id: this.currentQuizId++,
      moduleId: quiz.moduleId,
      question: quiz.question,
      options: quiz.options,
      correctAnswer: quiz.correctAnswer,
      explanation: quiz.explanation || null,
      difficulty: quiz.difficulty || "medium",
    };
    this.quizzes.set(newQuiz.id, newQuiz);
    return newQuiz;
  }

  // Quiz attempt methods
  async createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const newAttempt: QuizAttempt = {
      ...attempt,
      id: this.currentQuizAttemptId++,
      attemptedAt: new Date(),
    };
    this.quizAttempts.set(newAttempt.id, newAttempt);
    return newAttempt;
  }

  async getUserQuizAttempts(userId: number): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values())
      .filter(attempt => attempt.userId === userId)
      .sort((a, b) => b.attemptedAt.getTime() - a.attemptedAt.getTime());
  }

  // Achievement methods
  async getAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values())
      .filter(ua => ua.userId === userId);
  }

  async unlockAchievement(userId: number, achievementId: number): Promise<UserAchievement> {
    const userAchievement: UserAchievement = {
      id: this.currentUserAchievementId++,
      userId,
      achievementId,
      unlockedAt: new Date(),
    };
    this.userAchievements.set(`${userId}-${achievementId}`, userAchievement);
    return userAchievement;
  }

  // Study plan methods
  async getUserStudyPlans(userId: number): Promise<StudyPlan[]> {
    return Array.from(this.studyPlans.values())
      .filter(plan => plan.userId === userId);
  }

  async createStudyPlan(plan: InsertStudyPlan): Promise<StudyPlan> {
    const newPlan: StudyPlan = {
      id: this.currentStudyPlanId++,
      userId: plan.userId,
      moduleId: plan.moduleId,
      targetDate: plan.targetDate,
      dailyGoal: plan.dailyGoal || 30,
      isCompleted: plan.isCompleted || false,
      createdAt: new Date(),
    };
    this.studyPlans.set(newPlan.id, newPlan);
    return newPlan;
  }

  async updateStudyPlan(id: number, updates: Partial<StudyPlan>): Promise<StudyPlan | undefined> {
    const plan = this.studyPlans.get(id);
    if (!plan) return undefined;
    
    const updatedPlan = { ...plan, ...updates };
    this.studyPlans.set(id, updatedPlan);
    return updatedPlan;
  }
}

export const storage = new MemStorage();
