# DentalPT - Dental Education Platform

## Overview

DentalPT is a comprehensive web application designed for dental education, featuring interactive learning modules, quizzes, clinical simulations, and study planning tools. The platform serves both dental students and professionals with Portuguese language support and a modern, responsive interface.

## System Architecture

The application follows a full-stack architecture with:
- **Frontend**: React with TypeScript, built using Vite
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **Internationalization**: i18next for Portuguese/English support
- **State Management**: TanStack Query for server state, React Context for app state

## Key Components

### Frontend Architecture
- **React Router**: Wouter for lightweight routing
- **Component Structure**: Modular design with reusable UI components
- **Styling**: Tailwind CSS with custom dental-themed color palette
- **State Management**: 
  - TanStack Query for API data fetching and caching
  - Context providers for auth, theme, and language
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **API Design**: RESTful endpoints with Express.js
- **Data Access**: Abstracted storage interface supporting both in-memory and database implementations
- **Database Integration**: Drizzle ORM with PostgreSQL
- **Development Setup**: Hot reload with Vite integration

### Database Schema
Key entities include:
- **Users**: Authentication and profile management
- **Modules**: Learning content organization
- **User Progress**: Learning advancement tracking
- **Quizzes**: Assessment questions and answers
- **Quiz Attempts**: User performance history
- **Achievements**: Gamification system
- **Study Plans**: Personalized learning schedules

## Data Flow

1. **Authentication**: Context-based user management with local storage persistence
2. **Content Delivery**: Modules and lessons fetched via TanStack Query
3. **Progress Tracking**: Real-time updates to user advancement
4. **Quiz System**: Interactive assessments with immediate feedback
5. **Study Planning**: Calendar-based learning schedule management

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver
- **drizzle-orm**: Type-safe database queries
- **@tanstack/react-query**: Server state management
- **@radix-ui/react-***: Accessible UI primitives
- **react-hook-form**: Form handling
- **zod**: Schema validation
- **i18next**: Internationalization

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first styling
- **PostCSS**: CSS processing

## Deployment Strategy

### Production Build
- **Frontend**: Vite builds to `dist/public`
- **Backend**: esbuild compiles TypeScript to `dist/index.js`
- **Assets**: Static files served from built frontend

### Environment Configuration
- **Development**: Hot reload with Vite middleware
- **Production**: Optimized builds with Node.js server
- **Database**: PostgreSQL connection via environment variables

### Replit Configuration
- **Modules**: Node.js 20, Web, PostgreSQL 16
- **Deployment**: Autoscale with build and run commands
- **Port**: 5000 (internal) mapped to 80 (external)

## Recent Changes

### June 24, 2025
- ✓ Fixed application startup issues and TypeScript errors
- ✓ Corrected Form component exports and duplicated UI components
- ✓ Removed debug console.log statements for cleaner production code
- ✓ Added missing UI components: Skeleton, Separator, Sheet, Pagination
- ✓ Updated CSS variables for proper dark mode and sidebar theming
- ✓ Improved error handling and user experience
- ✓ Updated browserslist for better browser compatibility
- ✓ Application now running smoothly on port 5000 with all features working

## User Preferences

Preferred communication style: Simple, everyday language.