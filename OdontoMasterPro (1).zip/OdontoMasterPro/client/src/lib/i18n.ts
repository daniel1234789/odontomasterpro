import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  pt: {
    translation: {
      // Common
      "welcome": "Bem-vindo",
      "continue": "Continue seus estudos onde parou",
      "level": "Nível",
      "streak": "dias de sequência",
      "completed": "completo",
      "pending": "Pendente",
      "in_progress": "Em andamento",
      
      // Navigation
      "home": "Início",
      "modules": "Módulos",
      "quiz": "Quiz",
      "simulation": "Simulação",
      "library": "Biblioteca",
      "planner": "Planeador",
      "profile": "Perfil",
      "ranking": "Ranking",
      
      // Dashboard
      "daily_progress": "Progresso Diário",
      "goals_completed": "metas concluídas",
      "study_modules": "Módulos de Estudo",
      "view_all": "Ver todos",
      "quick_quiz": "Quiz Rápido",
      "questions_random": "perguntas aleatórias",
      "clinical_simulation": "Simulação Clínica",
      "real_cases": "Casos reais interativos",
      "study_planner": "Planeador de Estudos",
      "organize_routine": "Organize sua rotina",
      "offline_library": "Biblioteca Offline",
      "pdfs_videos": "PDFs e vídeos offline",
      "recent_activity": "Atividade Recente",
      "achievements": "Conquistas",
      
      // Modules
      "exodontia": "Exodontia",
      "periodontology": "Periodontologia",
      "restorative_dentistry": "Dentística Restauradora",
      "orthodontics": "Ortodontia",
      "endodontics": "Endodontia",
      "pharmacology": "Farmacologia",
      "sterilization": "Esterilização e Biossegurança",
      "radiology": "Radiologia",
      "dental_anatomy": "Anatomia Dental",
      "pediatric_dentistry": "Odontopediatria",
      "prosthetics": "Prótese e Cirurgia Oral",
      "special_patients": "Atendimento a Pacientes Especiais",
      "ethics": "Ética e Legislação Odontológica",
      
      // Module descriptions
      "exodontia_desc": "Técnicas de extração dental",
      "periodontology_desc": "Doenças periodontais",
      "restorative_desc": "Restaurações estéticas",
      "orthodontics_desc": "Correção de maloclusões",
      "endodontics_desc": "Tratamento de canal",
      "pharmacology_desc": "Medicamentos odontológicos",
      "sterilization_desc": "Protocolos de segurança",
      "radiology_desc": "Interpretação radiográfica",
      "anatomy_desc": "Estruturas dentárias",
      "pediatric_desc": "Odontologia infantil",
      "prosthetics_desc": "Reabilitação protética",
      "special_desc": "Cuidados especializados",
      "ethics_desc": "Aspectos legais",
      
      // Quiz
      "quiz_periodontology": "Quiz de Periodontologia",
      "question_of": "Pergunta {{current}} de {{total}}",
      "skip": "Pular",
      "answer": "Responder",
      "correct": "Correto!",
      "incorrect": "Incorreto",
      "score": "Pontuação",
      
      // Achievements
      "first_quiz": "Primeiro Quiz",
      "streak_7": "Sequência 7 dias",
      "periodontia_expert": "Especialista em Periodontia",
      "master": "Master",
      "unlocked": "Desbloqueada",
      "locked": "Bloqueada",
      
      // Common actions
      "new": "Novo",
      "popular": "Popular",
      "start": "Iniciar",
      "close": "Fechar",
      "save": "Salvar",
      "cancel": "Cancelar",
      "edit": "Editar",
      "delete": "Excluir",
      
      // Tagline
      "tagline": "Tudo que um futuro dentista precisa, na palma da mão!"
    }
  },
  en: {
    translation: {
      // Common
      "welcome": "Welcome",
      "continue": "Continue your studies where you left off",
      "level": "Level",
      "streak": "day streak",
      "completed": "completed",
      "pending": "Pending",
      "in_progress": "In progress",
      
      // Navigation
      "home": "Home",
      "modules": "Modules",
      "quiz": "Quiz",
      "simulation": "Simulation",
      "library": "Library",
      "planner": "Planner",
      "profile": "Profile",
      "ranking": "Ranking",
      
      // Dashboard
      "daily_progress": "Daily Progress",
      "goals_completed": "goals completed",
      "study_modules": "Study Modules",
      "view_all": "View all",
      "quick_quiz": "Quick Quiz",
      "questions_random": "random questions",
      "clinical_simulation": "Clinical Simulation",
      "real_cases": "Interactive real cases",
      "study_planner": "Study Planner",
      "organize_routine": "Organize your routine",
      "offline_library": "Offline Library",
      "pdfs_videos": "PDFs and offline videos",
      "recent_activity": "Recent Activity",
      "achievements": "Achievements",
      
      // Modules
      "exodontia": "Exodontia",
      "periodontology": "Periodontology",
      "restorative_dentistry": "Restorative Dentistry",
      "orthodontics": "Orthodontics",
      "endodontics": "Endodontics",
      "pharmacology": "Pharmacology",
      "sterilization": "Sterilization and Biosafety",
      "radiology": "Radiology",
      "dental_anatomy": "Dental Anatomy",
      "pediatric_dentistry": "Pediatric Dentistry",
      "prosthetics": "Prosthetics and Oral Surgery",
      "special_patients": "Special Needs Patient Care",
      "ethics": "Ethics and Dental Legislation",
      
      // Module descriptions
      "exodontia_desc": "Dental extraction techniques",
      "periodontology_desc": "Periodontal diseases",
      "restorative_desc": "Aesthetic restorations",
      "orthodontics_desc": "Malocclusion correction",
      "endodontics_desc": "Root canal treatment",
      "pharmacology_desc": "Dental medications",
      "sterilization_desc": "Safety protocols",
      "radiology_desc": "Radiographic interpretation",
      "anatomy_desc": "Dental structures",
      "pediatric_desc": "Pediatric dentistry",
      "prosthetics_desc": "Prosthetic rehabilitation",
      "special_desc": "Specialized care",
      "ethics_desc": "Legal aspects",
      
      // Quiz
      "quiz_periodontology": "Periodontology Quiz",
      "question_of": "Question {{current}} of {{total}}",
      "skip": "Skip",
      "answer": "Answer",
      "correct": "Correct!",
      "incorrect": "Incorrect",
      "score": "Score",
      
      // Achievements
      "first_quiz": "First Quiz",
      "streak_7": "7-day Streak",
      "periodontia_expert": "Periodontology Expert",
      "master": "Master",
      "unlocked": "Unlocked",
      "locked": "Locked",
      
      // Common actions
      "new": "New",
      "popular": "Popular",
      "start": "Start",
      "close": "Close",
      "save": "Save",
      "cancel": "Cancel",
      "edit": "Edit",
      "delete": "Delete",
      
      // Tagline
      "tagline": "Everything a future dentist needs, in the palm of your hand!"
    }
  },
  es: {
    translation: {
      // Common
      "welcome": "Bienvenido",
      "continue": "Continúa tus estudios donde los dejaste",
      "level": "Nivel",
      "streak": "días de racha",
      "completed": "completado",
      "pending": "Pendiente",
      "in_progress": "En progreso",
      
      // Navigation
      "home": "Inicio",
      "modules": "Módulos",
      "quiz": "Quiz",
      "simulation": "Simulación",
      "library": "Biblioteca",
      "planner": "Planificador",
      "profile": "Perfil",
      "ranking": "Ranking",
      
      // Dashboard
      "daily_progress": "Progreso Diario",
      "goals_completed": "metas completadas",
      "study_modules": "Módulos de Estudio",
      "view_all": "Ver todos",
      "quick_quiz": "Quiz Rápido",
      "questions_random": "preguntas aleatorias",
      "clinical_simulation": "Simulación Clínica",
      "real_cases": "Casos reales interactivos",
      "study_planner": "Planificador de Estudios",
      "organize_routine": "Organiza tu rutina",
      "offline_library": "Biblioteca Offline",
      "pdfs_videos": "PDFs y videos offline",
      "recent_activity": "Actividad Reciente",
      "achievements": "Logros",
      
      // Modules
      "exodontia": "Exodoncia",
      "periodontology": "Periodoncia",
      "restorative_dentistry": "Odontología Restauradora",
      "orthodontics": "Ortodoncia",
      "endodontics": "Endodoncia",
      "pharmacology": "Farmacología",
      "sterilization": "Esterilización y Bioseguridad",
      "radiology": "Radiología",
      "dental_anatomy": "Anatomía Dental",
      "pediatric_dentistry": "Odontopediatría",
      "prosthetics": "Prótesis y Cirugía Oral",
      "special_patients": "Atención a Pacientes Especiales",
      "ethics": "Ética y Legislación Odontológica",
      
      // Module descriptions
      "exodontia_desc": "Técnicas de extracción dental",
      "periodontology_desc": "Enfermedades periodontales",
      "restorative_desc": "Restauraciones estéticas",
      "orthodontics_desc": "Corrección de maloclusiones",
      "endodontics_desc": "Tratamiento de conductos",
      "pharmacology_desc": "Medicamentos odontológicos",
      "sterilization_desc": "Protocolos de seguridad",
      "radiology_desc": "Interpretación radiográfica",
      "anatomy_desc": "Estructuras dentales",
      "pediatric_desc": "Odontología infantil",
      "prosthetics_desc": "Rehabilitación protésica",
      "special_desc": "Cuidados especializados",
      "ethics_desc": "Aspectos legales",
      
      // Quiz
      "quiz_periodontology": "Quiz de Periodoncia",
      "question_of": "Pregunta {{current}} de {{total}}",
      "skip": "Saltar",
      "answer": "Responder",
      "correct": "¡Correcto!",
      "incorrect": "Incorrecto",
      "score": "Puntuación",
      
      // Achievements
      "first_quiz": "Primer Quiz",
      "streak_7": "Racha de 7 días",
      "periodontia_expert": "Experto en Periodoncia",
      "master": "Maestro",
      "unlocked": "Desbloqueado",
      "locked": "Bloqueado",
      
      // Common actions
      "new": "Nuevo",
      "popular": "Popular",
      "start": "Iniciar",
      "close": "Cerrar",
      "save": "Guardar",
      "cancel": "Cancelar",
      "edit": "Editar",
      "delete": "Eliminar",
      
      // Tagline
      "tagline": "¡Todo lo que un futuro dentista necesita, en la palma de tu mano!"
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "pt",
    fallbackLng: "en",
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;
