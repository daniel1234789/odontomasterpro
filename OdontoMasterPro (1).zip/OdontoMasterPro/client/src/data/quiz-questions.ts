export interface QuizQuestion {
  id: number;
  moduleId: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
  tags?: string[];
}

export const quizQuestions: QuizQuestion[] = [
  // Periodontology (Module 2)
  {
    id: 1,
    moduleId: 2,
    question: "Qual é a principal causa da doença periodontal?",
    options: [
      "Placa bacteriana",
      "Cálculo dental",
      "Trauma oclusal",
      "Fatores genéticos"
    ],
    correctAnswer: 0,
    explanation: "A placa bacteriana é a principal causa da doença periodontal, pois contém bactérias que produzem toxinas que irritam a gengiva e podem levar à destruição dos tecidos periodontais.",
    difficulty: "medium",
    tags: ["etiologia", "placa bacteriana", "doença periodontal"]
  },
  {
    id: 2,
    moduleId: 2,
    question: "O que caracteriza a gengivite?",
    options: [
      "Perda de inserção clínica",
      "Inflamação gengival sem perda de inserção",
      "Mobilidade dental",
      "Formação de bolsas periodontais"
    ],
    correctAnswer: 1,
    explanation: "A gengivite é caracterizada pela inflamação da gengiva sem perda de inserção clínica, sendo reversível com adequada higiene oral.",
    difficulty: "easy",
    tags: ["gengivite", "inflamação", "diagnóstico"]
  },
  {
    id: 3,
    moduleId: 2,
    question: "Qual a profundidade normal de sondagem do sulco gengival?",
    options: [
      "0-1mm",
      "1-3mm",
      "3-5mm",
      "5-7mm"
    ],
    correctAnswer: 1,
    explanation: "A profundidade normal de sondagem do sulco gengival varia de 1 a 3mm. Medidas acima de 3mm podem indicar a presença de bolsas periodontais.",
    difficulty: "medium",
    tags: ["sondagem", "diagnóstico", "exame periodontal"]
  },

  // Exodontia (Module 1)
  {
    id: 4,
    moduleId: 1,
    question: "Qual é a técnica mais segura para extração de terceiros molares inclusos?",
    options: [
      "Extração com fórceps",
      "Odontosecção",
      "Extração simples",
      "Curetagem"
    ],
    correctAnswer: 1,
    explanation: "A odontosecção é a técnica mais segura para terceiros molares inclusos, pois permite melhor controle, menor trauma aos tecidos adjacentes e reduz o risco de fratura mandibular.",
    difficulty: "hard",
    tags: ["terceiro molar", "cirurgia", "odontosecção"]
  },
  {
    id: 5,
    moduleId: 1,
    question: "Qual é a principal contraindicação absoluta para exodontia?",
    options: [
      "Hipertensão controlada",
      "Diabetes descompensado",
      "Infarto do miocárdio recente (menos de 6 meses)",
      "Uso de anticoagulantes"
    ],
    correctAnswer: 2,
    explanation: "Infarto do miocárdio recente (menos de 6 meses) é uma contraindicação absoluta para procedimentos eletivos devido ao alto risco cardiovascular.",
    difficulty: "hard",
    tags: ["contraindicação", "risco cardiovascular", "emergência"]
  },

  // Endodontia (Module 5)
  {
    id: 6,
    moduleId: 5,
    question: "Qual é o principal objetivo da instrumentação endodôntica?",
    options: [
      "Apenas remover a polpa",
      "Dar forma cônica ao canal",
      "Limpeza, modelagem e desinfecção",
      "Facilitar a obturação"
    ],
    correctAnswer: 2,
    explanation: "O principal objetivo da instrumentação endodôntica é a limpeza (remoção de tecido pulpar), modelagem (dar forma adequada) e desinfecção do sistema de canais radiculares.",
    difficulty: "medium",
    tags: ["instrumentação", "objetivos", "preparo biomecânico"]
  },
  {
    id: 7,
    moduleId: 5,
    question: "Qual é a solução irrigadora mais utilizada em endodontia?",
    options: [
      "Soro fisiológico",
      "Hipoclorito de sódio",
      "Peróxido de hidrogênio",
      "Clorexidina"
    ],
    correctAnswer: 1,
    explanation: "O hipoclorito de sódio é a solução irrigadora mais utilizada em endodontia devido às suas propriedades antimicrobianas e de dissolução de tecido orgânico.",
    difficulty: "easy",
    tags: ["irrigação", "hipoclorito", "desinfecção"]
  },

  // Dentística Restauradora (Module 3)
  {
    id: 8,
    moduleId: 3,
    question: "Qual é o principal componente dos sistemas adesivos atuais?",
    options: [
      "Bis-GMA",
      "HEMA",
      "TEGDMA",
      "MDP"
    ],
    correctAnswer: 0,
    explanation: "O Bis-GMA (Bisfenol A glicidil metacrilato) é o principal componente da matriz resinosa dos sistemas adesivos atuais, proporcionando boa adesão e resistência.",
    difficulty: "hard",
    tags: ["adesivos", "bis-gma", "química"]
  },
  {
    id: 9,
    moduleId: 3,
    question: "O que é o condicionamento ácido?",
    options: [
      "Remoção de cárie",
      "Desmineralização do esmalte e dentina",
      "Limpeza da cavidade",
      "Aplicação de flúor"
    ],
    correctAnswer: 1,
    explanation: "O condicionamento ácido promove a desmineralização superficial do esmalte e dentina, criando microporosidades que permitem a penetração do adesivo.",
    difficulty: "medium",
    tags: ["condicionamento ácido", "adesão", "técnica"]
  },

  // Farmacologia (Module 6)
  {
    id: 10,
    moduleId: 6,
    question: "Qual anestésico local tem maior duração de ação?",
    options: [
      "Lidocaína",
      "Prilocaína",
      "Bupivacaína",
      "Mepivacaína"
    ],
    correctAnswer: 2,
    explanation: "A bupivacaína tem a maior duração de ação entre os anestésicos locais comumente utilizados em odontologia, podendo durar até 8 horas.",
    difficulty: "medium",
    tags: ["anestésicos", "bupivacaína", "duração"]
  },
  {
    id: 11,
    moduleId: 6,
    question: "Qual é o analgésico de primeira escolha para dor dental?",
    options: [
      "Paracetamol",
      "Ibuprofeno",
      "Dipirona",
      "Ácido acetilsalicílico"
    ],
    correctAnswer: 1,
    explanation: "O ibuprofeno é considerado o analgésico de primeira escolha para dor dental devido ao seu efeito anti-inflamatório e analgésico específico para dor odontogênica.",
    difficulty: "easy",
    tags: ["analgésicos", "ibuprofeno", "dor dental"]
  },

  // Ortodontia (Module 4)
  {
    id: 12,
    moduleId: 4,
    question: "Qual é a idade ideal para iniciar o tratamento ortodôntico interceptivo?",
    options: [
      "4-6 anos",
      "7-9 anos",
      "10-12 anos",
      "13-15 anos"
    ],
    correctAnswer: 1,
    explanation: "A idade ideal para iniciar o tratamento ortodôntico interceptivo é entre 7-9 anos, durante a dentição mista, quando ainda é possível modificar o crescimento.",
    difficulty: "medium",
    tags: ["ortodontia interceptiva", "idade", "dentição mista"]
  },

  // Anatomia Dental (Module 9)
  {
    id: 13,
    moduleId: 9,
    question: "Quantas cúspides possui o primeiro molar superior?",
    options: [
      "2 cúspides",
      "3 cúspides",
      "4 cúspides",
      "5 cúspides"
    ],
    correctAnswer: 2,
    explanation: "O primeiro molar superior possui 4 cúspides: mesiovestibular, distovestibular, mesiolingual e distolingual.",
    difficulty: "easy",
    tags: ["anatomia", "molar superior", "cúspides"]
  },

  // Radiologia (Module 8)
  {
    id: 14,
    moduleId: 8,
    question: "Qual é a dose de radiação de uma radiografia periapical?",
    options: [
      "0,001-0,005 mSv",
      "0,005-0,01 mSv",
      "0,01-0,05 mSv",
      "0,05-0,1 mSv"
    ],
    correctAnswer: 1,
    explanation: "Uma radiografia periapical tem dose de radiação entre 0,005-0,01 mSv, sendo considerada um exame de baixa dose.",
    difficulty: "hard",
    tags: ["radiação", "dose", "periapical"]
  },

  // Odontopediatria (Module 10)
  {
    id: 15,
    moduleId: 10,
    question: "Qual é a técnica de manejo comportamental mais eficaz em crianças?",
    options: [
      "Contenção física",
      "Falar-mostrar-fazer",
      "Sedação",
      "Controle de voz"
    ],
    correctAnswer: 1,
    explanation: "A técnica 'falar-mostrar-fazer' é considerada a mais eficaz para manejo comportamental em crianças, pois reduz a ansiedade através da familiarização gradual.",
    difficulty: "easy",
    tags: ["odontopediatria", "manejo comportamental", "técnica"]
  }
];

export const getQuestionsByModule = (moduleId: number): QuizQuestion[] => {
  return quizQuestions.filter(q => q.moduleId === moduleId);
};

export const getQuestionsByDifficulty = (difficulty: "easy" | "medium" | "hard"): QuizQuestion[] => {
  return quizQuestions.filter(q => q.difficulty === difficulty);
};

export const getRandomQuestions = (count: number, moduleId?: number): QuizQuestion[] => {
  let filteredQuestions = quizQuestions;
  
  if (moduleId) {
    filteredQuestions = getQuestionsByModule(moduleId);
  }
  
  const shuffled = [...filteredQuestions].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};

export const getQuestionsByTags = (tags: string[]): QuizQuestion[] => {
  return quizQuestions.filter(q => 
    q.tags?.some(tag => tags.includes(tag))
  );
};
