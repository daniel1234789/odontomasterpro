export const dentalModules = [
  {
    id: 1,
    name: "Exodontia",
    nameKey: "exodontia",
    description: "Técnicas de extração dental",
    descriptionKey: "exodontia_desc",
    icon: "/images/modules/exodontia-icon.svg",
    color: "red",
    order: 1,
    totalLessons: 12,
    topics: [
      "Indicações e contraindicações",
      "Técnicas de anestesia local",
      "Instrumentação para exodontia",
      "Técnicas de extração simples",
      "Exodontia de dentes inclusos",
      "Complicações e manejo",
      "Cuidados pós-operatórios",
      "Exodontia em pacientes especiais",
      "Aspectos legais e éticos",
      "Casos clínicos complexos"
    ]
  },
  {
    id: 2,
    name: "Periodontologia",
    nameKey: "periodontology",
    description: "Doenças periodontais",
    descriptionKey: "periodontology_desc",
    icon: "/images/modules/periodontologia-icon.svg",
    color: "green",
    order: 2,
    totalLessons: 15,
    topics: [
      "Anatomia periodontal",
      "Etiologia da doença periodontal",
      "Classificação das doenças periodontais",
      "Exame periodontal",
      "Índices periodontais",
      "Raspagem e alisamento radicular",
      "Cirurgia periodontal",
      "Terapia periodontal regenerativa",
      "Manutenção periodontal",
      "Periodontia em pacientes especiais"
    ]
  },
  {
    id: 3,
    name: "Dentística Restauradora",
    nameKey: "restorative_dentistry",
    description: "Restaurações estéticas",
    descriptionKey: "restorative_desc",
    icon: "/images/modules/dentistica-icon.svg",
    color: "blue",
    order: 3,
    totalLessons: 18,
    topics: [
      "Cariologia",
      "Materiais restauradores",
      "Preparos cavitários",
      "Sistemas adesivos",
      "Restaurações diretas em resina",
      "Restaurações indiretas",
      "Clareamento dental",
      "Facetas em resina e porcelana",
      "Prótese adesiva",
      "Estética dental"
    ]
  },
  {
    id: 4,
    name: "Ortodontia",
    nameKey: "orthodontics",
    description: "Correção de maloclusões",
    descriptionKey: "orthodontics_desc",
    icon: "fas fa-smile",
    color: "purple",
    order: 4,
    totalLessons: 20,
    topics: [
      "Crescimento e desenvolvimento craniofacial",
      "Etiologia das maloclusões",
      "Classificação das maloclusões",
      "Diagnóstico ortodôntico",
      "Planejamento do tratamento",
      "Aparelhos ortodônticos",
      "Mecânica ortodôntica",
      "Tratamento interceptivo",
      "Ortodontia preventiva",
      "Contenção ortodôntica"
    ]
  },
  {
    id: 5,
    name: "Endodontia",
    nameKey: "endodontics",
    description: "Tratamento de canal",
    descriptionKey: "endodontics_desc",
    icon: "/images/modules/endodontia-icon.svg",
    color: "orange",
    order: 5,
    totalLessons: 14,
    topics: [
      "Anatomia da cavidade pulpar",
      "Diagnóstico pulpar",
      "Anestesia em endodontia",
      "Isolamento absoluto",
      "Acesso endodôntico",
      "Instrumentação endodôntica",
      "Irrigação e medicação",
      "Obturação do canal radicular",
      "Retratamento endodôntico",
      "Endodontia em dentes traumatizados"
    ]
  },
  {
    id: 6,
    name: "Farmacologia",
    nameKey: "pharmacology",
    description: "Medicamentos odontológicos",
    descriptionKey: "pharmacology_desc",
    icon: "fas fa-pills",
    color: "teal",
    order: 6,
    totalLessons: 10,
    topics: [
      "Princípios de farmacologia",
      "Anestésicos locais",
      "Analgésicos",
      "Anti-inflamatórios",
      "Antibióticos em odontologia",
      "Medicamentos para urgências",
      "Interações medicamentosas",
      "Prescrição odontológica",
      "Farmacologia em pacientes especiais",
      "Controle da ansiedade"
    ]
  },
  {
    id: 7,
    name: "Esterilização e Biossegurança",
    nameKey: "sterilization",
    description: "Protocolos de segurança",
    descriptionKey: "sterilization_desc",
    icon: "fas fa-shield-alt",
    color: "red",
    order: 7,
    totalLessons: 8,
    topics: [
      "Princípios de biossegurança",
      "Métodos de esterilização",
      "Desinfecção de superfícies",
      "Processamento de instrumentais",
      "Equipamentos de proteção individual",
      "Gerenciamento de resíduos",
      "Controle de infecção cruzada",
      "Protocolos de emergência"
    ]
  },
  {
    id: 8,
    name: "Radiologia",
    nameKey: "radiology",
    description: "Interpretação radiográfica",
    descriptionKey: "radiology_desc",
    icon: "fas fa-x-ray",
    color: "gray",
    order: 8,
    totalLessons: 12,
    topics: [
      "Física das radiações",
      "Equipamentos radiográficos",
      "Técnicas radiográficas",
      "Radioproteção",
      "Anatomia radiográfica normal",
      "Interpretação radiográfica",
      "Radiologia digital",
      "Tomografia computadorizada",
      "Ultrassonografia",
      "Patologias radiográficas"
    ]
  },
  {
    id: 9,
    name: "Anatomia Dental",
    nameKey: "dental_anatomy",
    description: "Estruturas dentárias",
    descriptionKey: "anatomy_desc",
    icon: "fas fa-brain",
    color: "indigo",
    order: 9,
    totalLessons: 16,
    topics: [
      "Embriologia dental",
      "Histologia dental",
      "Anatomia da coroa dental",
      "Anatomia radicular",
      "Oclusão dental",
      "Articulação temporomandibular",
      "Músculos da mastigação",
      "Inervação e vascularização",
      "Desenvolvimento da dentição",
      "Variações anatômicas"
    ]
  },
  {
    id: 10,
    name: "Odontopediatria",
    nameKey: "pediatric_dentistry",
    description: "Odontologia infantil",
    descriptionKey: "pediatric_desc",
    icon: "fas fa-child",
    color: "pink",
    order: 10,
    totalLessons: 13,
    topics: [
      "Psicologia infantil aplicada",
      "Desenvolvimento da dentição",
      "Cárie na primeira infância",
      "Prevenção em odontopediatria",
      "Tratamentos restauradores",
      "Pulpoterapia em dentes decíduos",
      "Traumatismo dental em crianças",
      "Anestesia em crianças",
      "Manejo comportamental",
      "Odontologia para bebês"
    ]
  },
  {
    id: 11,
    name: "Prótese e Cirurgia Oral",
    nameKey: "prosthetics",
    description: "Reabilitação protética",
    descriptionKey: "prosthetics_desc",
    icon: "fas fa-tools",
    color: "yellow",
    order: 11,
    totalLessons: 22,
    topics: [
      "Prótese total",
      "Prótese parcial removível",
      "Prótese fixa",
      "Implantodontia",
      "Cirurgia pré-protética",
      "Materiais protéticos",
      "Oclusão em prótese",
      "Prótese sobre implantes",
      "Cirurgia oral menor",
      "Patologia oral"
    ]
  },
  {
    id: 12,
    name: "Atendimento a Pacientes Especiais",
    nameKey: "special_patients",
    description: "Cuidados especializados",
    descriptionKey: "special_desc",
    icon: "fas fa-wheelchair",
    color: "purple",
    order: 12,
    totalLessons: 9,
    topics: [
      "Pacientes com deficiência",
      "Distúrbios neurológicos",
      "Cardiopatias",
      "Diabetes e endocrinopatias",
      "Gestantes",
      "Idosos",
      "Pacientes oncológicos",
      "Sedação consciente",
      "Adaptações no consultório"
    ]
  },
  {
    id: 13,
    name: "Ética e Legislação Odontológica",
    nameKey: "ethics",
    description: "Aspectos legais",
    descriptionKey: "ethics_desc",
    icon: "fas fa-balance-scale",
    color: "gray",
    order: 13,
    totalLessons: 7,
    topics: [
      "Código de ética odontológica",
      "Exercício profissional",
      "Responsabilidade civil",
      "Responsabilidade penal",
      "Documentação odontológica",
      "Perícia odontológica",
      "Publicidade em odontologia"
    ]
  }
];

export const getModuleByName = (name: string) => {
  return dentalModules.find(module => 
    module.name.toLowerCase() === name.toLowerCase() ||
    module.nameKey === name
  );
};

export const getModulesByCategory = (category: string) => {
  // Categories could be: clinical, surgical, preventive, diagnostic
  const categories = {
    clinical: [2, 3, 5, 10], // Periodontology, Restorative, Endodontics, Pediatrics
    surgical: [1, 11], // Exodontia, Prosthetics & Oral Surgery
    preventive: [7, 6], // Sterilization, Pharmacology
    diagnostic: [8, 9], // Radiology, Anatomy
    orthodontic: [4], // Orthodontics
    special: [12, 13] // Special needs, Ethics
  };
  
  const categoryIds = categories[category as keyof typeof categories] || [];
  return dentalModules.filter(module => categoryIds.includes(module.id));
};
