import { useState } from "react";
import { Search, Download, Play, FileText, Headphones, Video, Filter } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { useTranslation } from "react-i18next";

interface LibraryItem {
  id: number;
  title: string;
  description: string;
  type: "pdf" | "video" | "audio";
  module: string;
  duration?: string;
  size: string;
  downloadUrl: string;
  thumbnail?: string;
  isDownloaded: boolean;
}

export default function Library() {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterModule, setFilterModule] = useState("all");
  const [activeTab, setActiveTab] = useState("all");

  const libraryItems: LibraryItem[] = [
    {
      id: 1,
      title: "Técnicas de Exodontia Simples",
      description: "Guia completo sobre procedimentos básicos de extração dental",
      type: "pdf",
      module: "Exodontia",
      size: "2.3 MB",
      downloadUrl: "/content/exodontia-basica.pdf",
      isDownloaded: true
    },
    {
      id: 2,
      title: "Anatomia do Sistema Radicular",
      description: "Vídeo demonstrativo sobre morfologia radicular",
      type: "video",
      module: "Anatomia Dental",
      duration: "15:30",
      size: "45.2 MB",
      downloadUrl: "/content/anatomia-radicular.mp4",
      thumbnail: "/images/thumbnails/anatomia-thumbnail.jpg",
      isDownloaded: false
    },
    {
      id: 3,
      title: "Podcast: Tratamento Endodôntico Moderno",
      description: "Discussão sobre as últimas técnicas em endodontia",
      type: "audio",
      module: "Endodontia",
      duration: "32:15",
      size: "15.8 MB",
      downloadUrl: "/content/endodontia-podcast.mp3",
      thumbnail: "/images/thumbnails/endodontia-thumbnail.jpg",
      isDownloaded: true
    },
    {
      id: 4,
      title: "Protocolos de Periodontia",
      description: "Manual completo de procedimentos periodontais",
      type: "pdf",
      module: "Periodontologia",
      size: "4.1 MB",
      downloadUrl: "/content/protocolos-perio.pdf",
      isDownloaded: false
    },
    {
      id: 5,
      title: "Restaurações Estéticas Anteriores",
      description: "Técnicas avançadas em dentística restauradora",
      type: "video",
      module: "Dentística Restauradora",
      duration: "22:45",
      size: "67.3 MB",
      downloadUrl: "/content/restauracoes-esteticas.mp4",
      thumbnail: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isDownloaded: true
    },
    {
      id: 6,
      title: "Farmacologia em Odontologia",
      description: "Podcast sobre prescrição medicamentosa",
      type: "audio",
      module: "Farmacologia",
      duration: "28:12",
      size: "13.2 MB",
      downloadUrl: "/content/farmacologia-podcast.mp3",
      isDownloaded: false
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FileText className="w-5 h-5" />;
      case "video":
        return <Video className="w-5 h-5" />;
      case "audio":
        return <Headphones className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "pdf":
        return "text-red-600 bg-red-100 dark:bg-red-900/30";
      case "video":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900/30";
      case "audio":
        return "text-green-600 bg-green-100 dark:bg-green-900/30";
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-700";
    }
  };

  const filteredItems = libraryItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesModule = filterModule === "all" || item.module === filterModule;
    const matchesTab = activeTab === "all" || 
                      (activeTab === "downloaded" && item.isDownloaded) ||
                      (activeTab === "videos" && item.type === "video") ||
                      (activeTab === "pdfs" && item.type === "pdf") ||
                      (activeTab === "audio" && item.type === "audio");
    
    return matchesSearch && matchesModule && matchesTab;
  });

  const modules = [...new Set(libraryItems.map(item => item.module))];
  const downloadedCount = libraryItems.filter(item => item.isDownloaded).length;
  const totalSize = libraryItems
    .filter(item => item.isDownloaded)
    .reduce((acc, item) => acc + parseFloat(item.size.replace(" MB", "")), 0);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {t('offline_library')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Acesse seu conteúdo educacional mesmo sem conexão com a internet
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                  <Download className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {downloadedCount}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Itens baixados
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {libraryItems.length}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Total de itens
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
                  <Video className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {totalSize.toFixed(1)} MB
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Espaço utilizado
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar na biblioteca..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterModule} onValueChange={setFilterModule}>
            <SelectTrigger className="w-full sm:w-48">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filtrar por módulo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os módulos</SelectItem>
              {modules.map(module => (
                <SelectItem key={module} value={module}>{module}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="downloaded">Baixados</TabsTrigger>
            <TabsTrigger value="videos">Vídeos</TabsTrigger>
            <TabsTrigger value="pdfs">PDFs</TabsTrigger>
            <TabsTrigger value="audio">Áudio</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              {item.thumbnail && (
                <div className="aspect-video relative">
                  <img 
                    src={item.thumbnail} 
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <Button size="sm" className="bg-white/90 text-gray-900 hover:bg-white">
                      <Play className="w-4 h-4 mr-1" />
                      {item.duration}
                    </Button>
                  </div>
                </div>
              )}
              
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getTypeColor(item.type)}`}>
                    {getTypeIcon(item.type)}
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {item.module}
                  </Badge>
                </div>
                
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {item.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  {item.description}
                </p>
                
                <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-3">
                  <span>{item.size}</span>
                  {item.duration && <span>{item.duration}</span>}
                </div>
                
                <div className="flex space-x-2">
                  {item.isDownloaded ? (
                    <>
                      <Button size="sm" className="flex-1 bg-dental-blue-600 hover:bg-dental-blue-700">
                        <Play className="w-4 h-4 mr-1" />
                        Abrir
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4" />
                      </Button>
                    </>
                  ) : (
                    <Button size="sm" variant="outline" className="w-full">
                      <Download className="w-4 h-4 mr-1" />
                      Baixar
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500 dark:text-gray-400">
              Nenhum item encontrado com os filtros selecionados.
            </p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
