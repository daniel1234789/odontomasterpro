import { useState } from "react";
import { Play, Trophy, Clock, Target } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import QuizModal from "@/components/quiz/quiz-modal";
import { useAuth } from "@/contexts/auth-context";
import type { Quiz, QuizAttempt } from "@shared/schema";

export default function Quiz() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [showQuizModal, setShowQuizModal] = useState(false);
  const [selectedQuizzes, setSelectedQuizzes] = useState<Quiz[]>([]);

  const { data: randomQuizzes = [] } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes/random?count=10"],
  });

  const { data: quizAttempts = [] } = useQuery<QuizAttempt[]>({
    queryKey: ["/api/user", user?.id, "quiz-attempts"],
    enabled: !!user?.id,
  });

  const handleStartQuiz = (quizzes: Quiz[]) => {
    setSelectedQuizzes(quizzes);
    setShowQuizModal(true);
  };

  const handleQuizComplete = (score: number) => {
    // TODO: Save quiz result to backend
    setShowQuizModal(false);
  };

  const recentScores = quizAttempts.slice(0, 5);
  const averageScore = quizAttempts.length > 0 
    ? Math.round(quizAttempts.reduce((sum, attempt) => sum + (attempt.isCorrect ? 100 : 0), 0) / quizAttempts.length)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {t('quiz')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Teste seus conhecimentos com questões interativas
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {averageScore}%
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Média de acertos
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {quizAttempts.length}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Quizzes realizados
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {user?.streakDays || 0}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Dias consecutivos
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Quiz Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="card-hover cursor-pointer" onClick={() => handleStartQuiz(randomQuizzes.slice(0, 5))}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Play className="w-5 h-5 text-blue-600" />
                <span>Quiz Rápido</span>
                <Badge variant="secondary">5 min</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                5 questões aleatórias de diferentes módulos
              </p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Iniciar Quiz
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover cursor-pointer" onClick={() => handleStartQuiz(randomQuizzes.slice(0, 10))}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-green-600" />
                <span>Quiz Padrão</span>
                <Badge variant="secondary">10 min</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                10 questões com nível de dificuldade progressivo
              </p>
              <Button className="w-full bg-green-600 hover:bg-green-700">
                Iniciar Quiz
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover cursor-pointer" onClick={() => handleStartQuiz(randomQuizzes)}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5 text-red-600" />
                <span>Quiz Desafio</span>
                <Badge variant="secondary">20 min</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                20 questões avançadas para testar seu domínio
              </p>
              <Button className="w-full bg-red-600 hover:bg-red-700">
                Iniciar Quiz
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Attempts */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico Recente</CardTitle>
          </CardHeader>
          <CardContent>
            {recentScores.length > 0 ? (
              <div className="space-y-4">
                {recentScores.map((attempt) => (
                  <div key={attempt.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        Quiz #{attempt.id}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {new Date(attempt.attemptedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant={attempt.isCorrect ? "default" : "destructive"}>
                        {attempt.isCorrect ? "Correto" : "Incorreto"}
                      </Badge>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {attempt.timeSpent}s
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                Nenhum quiz realizado ainda. Comece com um quiz rápido!
              </p>
            )}
          </CardContent>
        </Card>
      </main>

      <BottomNav />
      
      <QuizModal
        open={showQuizModal}
        onClose={() => setShowQuizModal(false)}
        quizzes={selectedQuizzes}
        onComplete={handleQuizComplete}
      />
    </div>
  );
}
