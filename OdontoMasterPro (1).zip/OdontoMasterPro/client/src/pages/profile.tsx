import { useState } from "react";
import { User, Settings, Award, Languages, Moon, Sun, Smartphone, Mail, Calendar, Trophy, Target, BookOpen } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { useAuth } from "@/contexts/auth-context";
import { useTheme } from "@/contexts/theme-context";
import { useLanguage } from "@/contexts/language-context";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import type { User as UserType } from "@shared/schema";

const profileSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  mode: z.enum(["student", "professional"]),
});

type ProfileForm = z.infer<typeof profileSchema>;

export default function Profile() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage } = useLanguage();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [notifications, setNotifications] = useState(true);

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      mode: user?.mode || "student",
    },
  });

  const { data: userAchievements = [] } = useQuery({
    queryKey: ["/api/user", user?.id, "achievements"],
    enabled: !!user?.id,
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ["/api/user", user?.id, "progress"],
    enabled: !!user?.id,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileForm) => {
      const response = await apiRequest("PUT", `/api/user/${user?.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user", user?.id] });
      setShowEditDialog(false);
    },
  });

  const onSubmit = (data: ProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  const unlockedAchievements = userAchievements.filter((a: any) => a.unlocked);
  const totalModules = 13;
  const completedModules = userProgress.filter(p => p.score === 100).length;
  const averageScore = userProgress.length > 0 
    ? Math.round(userProgress.reduce((sum, p) => sum + p.score, 0) / userProgress.length)
    : 0;

  const stats = [
    {
      icon: Trophy,
      label: "Conquistas",
      value: unlockedAchievements.length,
      color: "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30"
    },
    {
      icon: Target,
      label: "Módulos Concluídos",
      value: `${completedModules}/${totalModules}`,
      color: "text-green-600 bg-green-100 dark:bg-green-900/30"
    },
    {
      icon: BookOpen,
      label: "Média de Acertos",
      value: `${averageScore}%`,
      color: "text-blue-600 bg-blue-100 dark:bg-blue-900/30"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {t('profile')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Gerencie suas configurações e acompanhe seu progresso
          </p>
        </div>

        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Avatar className="w-24 h-24">
                <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`} />
                <AvatarFallback className="text-xl">
                  {user?.name?.split(' ').map(n => n[0]).join('').toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {user?.name}
                </h2>
                <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-2 sm:space-y-0 sm:space-x-4">
                  <Badge variant="secondary" className="text-sm">
                    {user?.mode === "student" ? "Estudante" : "Profissional"}
                  </Badge>
                  <Badge className="bg-dental-blue-600 text-sm">
                    {t('level')} {user?.level}
                  </Badge>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Calendar className="w-4 h-4 mr-1" />
                    Membro desde {new Date(user?.createdAt || '').toLocaleDateString()}
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mt-2">
                  {user?.totalPoints} pontos • {user?.streakDays} dias de sequência
                </p>
              </div>
              
              <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Settings className="w-4 h-4 mr-2" />
                    Editar Perfil
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Editar Perfil</DialogTitle>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="mode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Modo</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="student">Estudante</SelectItem>
                                <SelectItem value="professional">Profissional</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end space-x-2">
                        <Button type="button" variant="outline" onClick={() => setShowEditDialog(false)}>
                          Cancelar
                        </Button>
                        <Button type="submit" disabled={updateProfileMutation.isPending}>
                          {updateProfileMutation.isPending ? "Salvando..." : "Salvar"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="stats" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="stats">Estatísticas</TabsTrigger>
            <TabsTrigger value="achievements">Conquistas</TabsTrigger>
            <TabsTrigger value="settings">Configurações</TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-6">
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <Card key={index}>
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.color}`}>
                          <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-gray-900 dark:text-white">
                            {stat.value}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {stat.label}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Progress Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Visão Geral do Progresso</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Progresso Geral
                    </span>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {Math.round((completedModules / totalModules) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                    <div 
                      className="progress-bar h-3 rounded-full transition-all duration-300" 
                      style={{ width: `${(completedModules / totalModules) * 100}%` }}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-dental-blue-600">
                        {user?.totalPoints}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Pontos Totais
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-dental-green-600">
                        {user?.streakDays}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Dias de Sequência
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userAchievements.map((achievement: any) => (
                <Card key={achievement.id} className={`overflow-hidden ${achievement.unlocked ? '' : 'opacity-50'}`}>
                  <CardContent className="p-6 text-center">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                      achievement.unlocked 
                        ? 'bg-yellow-100 dark:bg-yellow-900/30' 
                        : 'bg-gray-100 dark:bg-gray-700'
                    }`}>
                      <i className={`${achievement.icon} text-2xl ${
                        achievement.unlocked ? 'text-yellow-600' : 'text-gray-400'
                      }`}></i>
                    </div>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {achievement.name}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      {achievement.description}
                    </p>
                    <Badge variant={achievement.unlocked ? "default" : "secondary"}>
                      {achievement.unlocked ? t('unlocked') : t('locked')}
                    </Badge>
                    {achievement.unlocked && achievement.unlockedAt && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                        Desbloqueada em {new Date(achievement.unlockedAt).toLocaleDateString()}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Preferências</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Theme Toggle */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {theme === "light" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Tema Escuro</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Ativar modo escuro para reduzir o cansaço visual
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={theme === "dark"}
                    onCheckedChange={toggleTheme}
                  />
                </div>

                {/* Language Selection */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Languages className="w-5 h-5" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Idioma</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Escolha seu idioma preferido
                      </p>
                    </div>
                  </div>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pt">Português</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Notifications */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Smartphone className="w-5 h-5" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Notificações</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Receber lembretes de estudo
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={notifications}
                    onCheckedChange={setNotifications}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Conta</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">Email</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{user?.email}</p>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <Button 
                    variant="destructive" 
                    onClick={logout}
                    className="w-full"
                  >
                    Sair da Conta
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <BottomNav />
    </div>
  );
}
