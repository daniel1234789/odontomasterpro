import { useState } from "react";
import { Play, Users, Clock, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";

export default function Simulation() {
  const [selectedCase, setSelectedCase] = useState<number | null>(null);

  const clinicalCases = [
    {
      id: 1,
      title: "Dor de Dente Aguda",
      description: "Paciente de 35 anos com dor intensa no dente 16",
      difficulty: "Iniciante",
      duration: "15 min",
      participants: 1243,
      category: "Endodontia",
      image: "https://images.unsplash.com/photo-1609207791300-4b05e5eab426?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    },
    {
      id: 2,
      title: "Sangramento Gengival",
      description: "Paciente com histórico de gengivite crônica",
      difficulty: "Intermediário",
      duration: "20 min",
      participants: 892,
      category: "Periodontologia",
      image: "https://images.unsplash.com/photo-1622126807280-9b5b142e8d7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    },
    {
      id: 3,
      title: "Fratura Dental Complexa",
      description: "Trauma dental com exposição pulpar",
      difficulty: "Avançado",
      duration: "30 min",
      participants: 567,
      category: "Traumatologia",
      image: "https://images.unsplash.com/photo-1581447109200-bf2769ed8d40?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    },
    {
      id: 4,
      title: "Extração Cirúrgica",
      description: "Terceiro molar incluso com risco de complicações",
      difficulty: "Avançado",
      duration: "25 min",
      participants: 734,
      category: "Cirurgia",
      image: "https://images.unsplash.com/photo-1579952363873-27d3bfad9c0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Iniciante":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "Intermediário":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      case "Avançado":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Simulações Clínicas
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Pratique com casos reais e tome decisões clínicas fundamentadas
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <Play className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">12</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Casos Completados</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                  <Award className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">85%</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Taxa de Acerto</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">4h</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Tempo Total</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">#245</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Ranking Global</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Clinical Cases */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {clinicalCases.map((case_) => (
            <Card key={case_.id} className="card-hover cursor-pointer overflow-hidden">
              <div className="aspect-video relative">
                <img 
                  src={case_.image} 
                  alt={case_.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <Badge className={getDifficultyColor(case_.difficulty)}>
                    {case_.difficulty}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <Badge variant="secondary">{case_.category}</Badge>
                </div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-2">
                  {case_.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                  {case_.description}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{case_.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="w-4 h-4" />
                      <span>{case_.participants.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
                
                <Button 
                  className="w-full bg-dental-blue-600 hover:bg-dental-blue-700"
                  onClick={() => setSelectedCase(case_.id)}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Iniciar Simulação
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Coming Soon */}
        <Card className="mt-8">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Play className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Mais Simulações em Breve
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Estamos trabalhando em novos casos clínicos interativos para enriquecer sua experiência de aprendizado.
            </p>
            <Button variant="outline">
              Notificar-me sobre novos casos
            </Button>
          </CardContent>
        </Card>
      </main>

      <BottomNav />
    </div>
  );
}
