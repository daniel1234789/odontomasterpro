import { useState } from "react";
import { Calendar, Clock, Target, Plus, Edit2, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Progress } from "@/components/ui/progress";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import { useAuth } from "@/contexts/auth-context";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, addDays, isToday, isFuture } from "date-fns";
import { ptBR } from "date-fns/locale";
import { apiRequest } from "@/lib/queryClient";
import type { StudyPlan, Module } from "@shared/schema";

const studyPlanSchema = z.object({
  moduleId: z.number().min(1, "Selecione um módulo"),
  targetDate: z.date({
    required_error: "Selecione uma data",
  }),
  dailyGoal: z.number().min(15, "Mínimo de 15 minutos").max(480, "Máximo de 8 horas"),
  notes: z.string().optional(),
});

type StudyPlanForm = z.infer<typeof studyPlanSchema>;

export default function Planner() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const form = useForm<StudyPlanForm>({
    resolver: zodResolver(studyPlanSchema),
    defaultValues: {
      dailyGoal: 30,
      targetDate: addDays(new Date(), 7),
    },
  });

  const { data: studyPlans = [] } = useQuery<StudyPlan[]>({
    queryKey: ["/api/user", user?.id, "study-plans"],
    enabled: !!user?.id,
  });

  const { data: modules = [] } = useQuery<Module[]>({
    queryKey: ["/api/modules"],
  });

  const createPlanMutation = useMutation({
    mutationFn: async (data: StudyPlanForm) => {
      const response = await apiRequest("POST", "/api/study-plans", {
        userId: user?.id,
        ...data,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user", user?.id, "study-plans"] });
      setShowCreateDialog(false);
      form.reset();
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: async (planId: number) => {
      await apiRequest("DELETE", `/api/study-plans/${planId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user", user?.id, "study-plans"] });
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<StudyPlan>) => {
      const response = await apiRequest("PUT", `/api/study-plans/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user", user?.id, "study-plans"] });
    },
  });

  const onSubmit = (data: StudyPlanForm) => {
    createPlanMutation.mutate(data);
  };

  const togglePlanCompletion = (plan: StudyPlan) => {
    updatePlanMutation.mutate({
      id: plan.id,
      isCompleted: !plan.isCompleted,
    });
  };

  const getModuleName = (moduleId: number) => {
    const module = modules.find(m => m.id === moduleId);
    return module?.name || "Módulo não encontrado";
  };

  const activePlans = studyPlans.filter(plan => !plan.isCompleted);
  const completedPlans = studyPlans.filter(plan => plan.isCompleted);
  const todayPlans = activePlans.filter(plan => 
    isToday(new Date(plan.targetDate))
  );

  const totalDailyGoal = todayPlans.reduce((sum, plan) => sum + plan.dailyGoal, 0);
  const completedToday = todayPlans.filter(plan => plan.isCompleted).length;
  const progressPercentage = todayPlans.length > 0 ? (completedToday / todayPlans.length) * 100 : 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                {t('study_planner')}
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                {t('organize_routine')}
              </p>
            </div>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-dental-blue-600 hover:bg-dental-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Plano
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Criar Plano de Estudos</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="moduleId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Módulo</FormLabel>
                          <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione um módulo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {modules.map((module) => (
                                <SelectItem key={module.id} value={module.id.toString()}>
                                  {module.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="targetDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Data Alvo</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant="outline"
                                  className="w-full pl-3 text-left font-normal"
                                >
                                  {field.value ? (
                                    format(field.value, "PPP", { locale: ptBR })
                                  ) : (
                                    <span>Selecione uma data</span>
                                  )}
                                  <Calendar className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <CalendarComponent
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) =>
                                  date < new Date() || date < new Date("1900-01-01")
                                }
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="dailyGoal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Meta Diária (minutos)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Observações (opcional)</FormLabel>
                          <FormControl>
                            <Textarea {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                        Cancelar
                      </Button>
                      <Button type="submit" disabled={createPlanMutation.isPending}>
                        {createPlanMutation.isPending ? "Criando..." : "Criar Plano"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Today's Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-dental-blue-600" />
              <span>Progresso de Hoje</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {completedToday} de {todayPlans.length} tarefas concluídas
                </span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {Math.round(progressPercentage)}%
                </span>
              </div>
              <Progress value={progressPercentage} className="h-3" />
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600 dark:text-gray-400">
                    Meta: {totalDailyGoal} min
                  </span>
                </div>
                <span className="text-dental-green-600 font-medium">
                  {todayPlans.length} planos ativos
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active Plans */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Planos Ativos
            </h2>
            <div className="space-y-4">
              {activePlans.map((plan) => (
                <Card key={plan.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                          {getModuleName(plan.moduleId)}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Meta: {plan.dailyGoal} min/dia
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={isToday(new Date(plan.targetDate)) ? "default" : "secondary"}>
                          {format(new Date(plan.targetDate), "dd/MM", { locale: ptBR })}
                        </Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deletePlanMutation.mutate(plan.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Button
                        size="sm"
                        variant={plan.isCompleted ? "default" : "outline"}
                        onClick={() => togglePlanCompletion(plan)}
                        className={plan.isCompleted ? "bg-dental-green-500 hover:bg-dental-green-600" : ""}
                      >
                        {plan.isCompleted ? "Concluído" : "Marcar como concluído"}
                      </Button>
                      
                      <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                        <Calendar className="w-4 h-4" />
                        <span>
                          {isFuture(new Date(plan.targetDate)) ? "Em " : ""}
                          {format(new Date(plan.targetDate), "dd/MM/yyyy")}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {activePlans.length === 0 && (
                <div className="text-center py-8">
                  <Target className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Nenhum plano ativo. Crie seu primeiro plano de estudos!
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Completed Plans */}
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Planos Concluídos
            </h2>
            <div className="space-y-4">
              {completedPlans.slice(0, 5).map((plan) => (
                <Card key={plan.id} className="opacity-75">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                          {getModuleName(plan.moduleId)}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Concluído em {format(new Date(plan.targetDate), "dd/MM/yyyy")}
                        </p>
                      </div>
                      <Badge className="bg-dental-green-500">
                        ✓ Concluído
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {completedPlans.length === 0 && (
                <div className="text-center py-8">
                  <Trophy className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Nenhum plano concluído ainda.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Statistics */}
        <Card>
          <CardHeader>
            <CardTitle>Estatísticas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-dental-blue-600 mb-2">
                  {activePlans.length}
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Planos Ativos
                </p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-dental-green-600 mb-2">
                  {completedPlans.length}
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Planos Concluídos
                </p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">
                  {Math.round(totalDailyGoal / 60 * 10) / 10}h
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Meta Diária Total
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNav />
    </div>
  );
}
