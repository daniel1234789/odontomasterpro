import { useState } from "react";
import { Search, Filter } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import ModuleCard from "@/components/common/module-card";
import { useAuth } from "@/contexts/auth-context";
import type { Module, UserProgress } from "@shared/schema";

export default function Modules() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterBy, setFilterBy] = useState("all");

  const { data: modules = [] } = useQuery<Module[]>({
    queryKey: ["/api/modules"],
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/user", user?.id, "progress"],
    enabled: !!user?.id,
  });

  const progressMap = new Map(
    userProgress.map(p => [p.moduleId, p])
  );

  // Filter and search modules
  const filteredModules = modules.filter(module => {
    const matchesSearch = module.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         module.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;
    
    const progress = progressMap.get(module.id);
    const progressPercentage = progress ? (progress.completedLessons / progress.totalLessons) * 100 : 0;
    
    switch (filterBy) {
      case "completed":
        return progressPercentage === 100;
      case "in_progress":
        return progressPercentage > 0 && progressPercentage < 100;
      case "not_started":
        return progressPercentage === 0;
      default:
        return true;
    }
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {t('study_modules')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Explore todos os módulos educacionais disponíveis
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar módulos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterBy} onValueChange={setFilterBy}>
            <SelectTrigger className="w-full sm:w-48">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os módulos</SelectItem>
              <SelectItem value="completed">Concluídos</SelectItem>
              <SelectItem value="in_progress">Em progresso</SelectItem>
              <SelectItem value="not_started">Não iniciados</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredModules.map((module) => (
            <ModuleCard
              key={module.id}
              module={module}
              progress={progressMap.get(module.id)}
              onClick={() => {/* TODO: Navigate to module details */}}
            />
          ))}
        </div>

        {filteredModules.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">
              Nenhum módulo encontrado com os filtros selecionados.
            </p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
