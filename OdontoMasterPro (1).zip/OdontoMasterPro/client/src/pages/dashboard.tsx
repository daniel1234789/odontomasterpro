import { useState } from "react";
import { ArrowRight, Trophy, Flame, CheckCircle, Clock, Book } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/header";
import BottomNav from "@/components/layout/bottom-nav";
import ModuleCard from "@/components/common/module-card";
import ProgressBar from "@/components/common/progress-bar";
import QuizModal from "@/components/quiz/quiz-modal";
import { useAuth } from "@/contexts/auth-context";
import type { Module, UserProgress, Quiz } from "@shared/schema";

export default function Dashboard() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [showQuizModal, setShowQuizModal] = useState(false);

  const { data: modules = [] } = useQuery<Module[]>({
    queryKey: ["/api/modules"],
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/user", user?.id, "progress"],
    enabled: !!user?.id,
  });

  const { data: randomQuizzes = [] } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes/random?count=10"],
  });

  const { data: userAchievements = [] } = useQuery({
    queryKey: ["/api/user", user?.id, "achievements"],
    enabled: !!user?.id,
  });

  const completedGoals = 3;
  const totalGoals = 5;
  const dailyProgress = (completedGoals / totalGoals) * 100;

  const handleQuizComplete = (score: number) => {
    // TODO: Save quiz result to backend
    setShowQuizModal(false);
  };

  const progressMap = new Map(
    userProgress.map(p => [p.moduleId, p])
  );

  // Get modules with highest progress for display
  const featuredModules = modules.slice(0, 8);

  const unlockedAchievements = userAchievements.filter((a: any) => a.unlocked).length;
  const totalAchievements = userAchievements.length;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20 md:pb-6">
        {/* Welcome Hero Section */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="flex-1 mb-4 md:mb-0">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {t('welcome')}, <span className="text-dental-blue-600">{user?.name}</span>! 👋
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4">{t('continue')}</p>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-dental-green-500 rounded-full flex items-center justify-center mr-2">
                      <Trophy className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {t('level')} {user?.level}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center mr-2">
                      <Flame className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {user?.streakDays} {t('streak')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex-shrink-0">
                <img 
                  src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                  alt="Dental professional studying" 
                  className="w-32 h-24 object-cover rounded-xl shadow-lg"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Daily Progress */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {t('daily_progress')}
              </h3>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {completedGoals} de {totalGoals} {t('goals_completed')}
              </span>
            </div>
            <ProgressBar progress={dailyProgress} className="mb-4" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Quiz Periodontologia
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('completed')}
                  </p>
                </div>
              </div>
              <div className="flex items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Clock className="w-5 h-5 text-blue-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    Estudo: Endodontia
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('in_progress')}
                  </p>
                </div>
              </div>
              <div className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <Book className="w-5 h-5 text-gray-400 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {t('library')}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('pending')}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Study Modules */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
              {t('study_modules')}
            </h3>
            <Button variant="ghost" className="text-dental-blue-600 hover:text-dental-blue-700">
              {t('view_all')} <ArrowRight className="ml-1 w-4 h-4" />
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredModules.map((module) => (
              <ModuleCard
                key={module.id}
                module={module}
                progress={progressMap.get(module.id)}
                onClick={() => {/* TODO: Navigate to module details */}}
              />
            ))}
          </div>
        </section>

        {/* Quick Actions */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card 
            className="bg-gradient-to-br from-blue-500 to-blue-600 text-white card-hover cursor-pointer"
            onClick={() => setShowQuizModal(true)}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-question-circle text-white text-xl"></i>
                </div>
                <Badge className="bg-white/20 text-white border-0">
                  {t('new')}
                </Badge>
              </div>
              <h4 className="font-semibold mb-2">{t('quick_quiz')}</h4>
              <p className="text-blue-100 text-sm">10 {t('questions_random')}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white card-hover cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-stethoscope text-white text-xl"></i>
                </div>
                <Badge className="bg-white/20 text-white border-0">
                  {t('popular')}
                </Badge>
              </div>
              <h4 className="font-semibold mb-2">{t('clinical_simulation')}</h4>
              <p className="text-green-100 text-sm">{t('real_cases')}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white card-hover cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-calendar-alt text-white text-xl"></i>
                </div>
              </div>
              <h4 className="font-semibold mb-2">{t('study_planner')}</h4>
              <p className="text-purple-100 text-sm">{t('organize_routine')}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white card-hover cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-book text-white text-xl"></i>
                </div>
              </div>
              <h4 className="font-semibold mb-2">{t('offline_library')}</h4>
              <p className="text-orange-100 text-sm">{t('pdfs_videos')}</p>
            </CardContent>
          </Card>
        </section>

        {/* Recent Activity & Achievements */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activity */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('recent_activity')}
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Quiz de Periodontologia concluído
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Pontuação: 95% - Há 2 horas
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                    <Book className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Módulo de Exodontia estudado
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      45 minutos - Ontem
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center">
                    <Trophy className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Conquista desbloqueada: "Especialista em Periodontia"
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Há 2 dias
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('achievements')}
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="w-16 h-16 bg-yellow-100 dark:bg-yellow-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
                    <i className="fas fa-medal text-yellow-600 text-xl"></i>
                  </div>
                  <p className="text-xs font-medium text-gray-900 dark:text-white">
                    {t('first_quiz')}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('unlocked')}
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-2">
                    <i className="fas fa-crown text-green-600 text-xl"></i>
                  </div>
                  <p className="text-xs font-medium text-gray-900 dark:text-white">
                    {t('streak_7')}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('unlocked')}
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-2">
                    <i className="fas fa-lock text-gray-400 text-xl"></i>
                  </div>
                  <p className="text-xs font-medium text-gray-900 dark:text-white">
                    {t('master')}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('locked')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <BottomNav />
      
      <QuizModal
        open={showQuizModal}
        onClose={() => setShowQuizModal(false)}
        quizzes={randomQuizzes}
        onComplete={handleQuizComplete}
      />
    </div>
  );
}
