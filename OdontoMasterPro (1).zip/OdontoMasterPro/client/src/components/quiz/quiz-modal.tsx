import { useState } from "react";
import { X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import ProgressBar from "@/components/common/progress-bar";
import type { Quiz } from "@shared/schema";
import { useTranslation } from "react-i18next";

interface QuizModalProps {
  open: boolean;
  onClose: () => void;
  quizzes: Quiz[];
  onComplete: (score: number) => void;
}

export default function QuizModal({ open, onClose, quizzes, onComplete }: QuizModalProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [answers, setAnswers] = useState<number[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);
  const { t } = useTranslation();

  const currentQuiz = quizzes[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / quizzes.length) * 100;
  const isLastQuestion = currentQuestionIndex === quizzes.length - 1;

  const handleAnswerSubmit = () => {
    const answerIndex = parseInt(selectedAnswer);
    const newAnswers = [...answers, answerIndex];
    setAnswers(newAnswers);
    setShowFeedback(true);

    // Auto-advance after showing feedback
    setTimeout(() => {
      if (isLastQuestion) {
        // Calculate score and complete quiz
        const correctAnswers = newAnswers.filter((answer, index) => 
          answer === quizzes[index].correctAnswer
        ).length;
        const score = Math.round((correctAnswers / quizzes.length) * 100);
        onComplete(score);
        handleClose();
      } else {
        setCurrentQuestionIndex(prev => prev + 1);
        setSelectedAnswer("");
        setShowFeedback(false);
      }
    }, 2000);
  };

  const handleSkip = () => {
    setAnswers([...answers, -1]); // -1 indicates skipped
    if (isLastQuestion) {
      const correctAnswers = answers.filter((answer, index) => 
        answer === quizzes[index].correctAnswer
      ).length;
      const score = Math.round((correctAnswers / answers.length) * 100);
      onComplete(score);
      handleClose();
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer("");
    }
  };

  const handleClose = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer("");
    setAnswers([]);
    setShowFeedback(false);
    onClose();
  };

  if (!currentQuiz) return null;

  const isCorrect = showFeedback && parseInt(selectedAnswer) === currentQuiz.correctAnswer;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-screen overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl font-bold">
                {t('quiz_periodontology')}
              </DialogTitle>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('question_of', { current: currentQuestionIndex + 1, total: quizzes.length })}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          <ProgressBar progress={progress} />

          <div>
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {currentQuiz.question}
            </h4>
            
            <RadioGroup
              value={selectedAnswer}
              onValueChange={setSelectedAnswer}
              disabled={showFeedback}
              className="space-y-3"
            >
              {(currentQuiz.options as string[]).map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label 
                    htmlFor={`option-${index}`}
                    className={`flex-1 p-4 border-2 rounded-xl cursor-pointer transition-colors ${
                      showFeedback && index === currentQuiz.correctAnswer
                        ? "border-green-500 bg-green-50 dark:bg-green-900/20"
                        : showFeedback && selectedAnswer === index.toString() && index !== currentQuiz.correctAnswer
                        ? "border-red-500 bg-red-50 dark:bg-red-900/20"
                        : selectedAnswer === index.toString()
                        ? "border-dental-blue-600 bg-dental-blue-50 dark:bg-dental-blue-900/20"
                        : "border-gray-200 dark:border-gray-600 hover:border-dental-blue-300"
                    }`}
                  >
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {showFeedback && (
            <div className={`p-4 rounded-lg ${
              isCorrect 
                ? "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800"
                : "bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800"
            }`}>
              <div className="flex items-center space-x-2 mb-2">
                <Badge variant={isCorrect ? "default" : "destructive"}>
                  {isCorrect ? t('correct') : t('incorrect')}
                </Badge>
              </div>
              {currentQuiz.explanation && (
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  {currentQuiz.explanation}
                </p>
              )}
            </div>
          )}

          {!showFeedback && (
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={handleSkip}
              >
                {t('skip')}
              </Button>
              <Button
                onClick={handleAnswerSubmit}
                disabled={!selectedAnswer}
                className="bg-dental-blue-600 hover:bg-dental-blue-700"
              >
                {t('answer')}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
