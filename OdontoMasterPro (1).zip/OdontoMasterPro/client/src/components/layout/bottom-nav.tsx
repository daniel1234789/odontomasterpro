import { Home, GraduationCap, HelpCircle, Trophy, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";

export default function BottomNav() {
  const [location] = useLocation();
  const { t } = useTranslation();

  const navItems = [
    { icon: Home, label: t('home'), path: "/" },
    { icon: GraduationCap, label: t('modules'), path: "/modules" },
    { icon: HelpCircle, label: t('quiz'), path: "/quiz" },
    { icon: Trophy, label: t('ranking'), path: "/ranking" },
    { icon: User, label: t('profile'), path: "/profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2 md:hidden">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link key={item.path} href={item.path}>
              <button
                className={`flex flex-col items-center py-2 px-3 transition-colors ${
                  isActive 
                    ? "text-dental-blue-600" 
                    : "text-gray-400 hover:text-dental-blue-600"
                }`}
              >
                <Icon className="w-6 h-6 mb-1" />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
