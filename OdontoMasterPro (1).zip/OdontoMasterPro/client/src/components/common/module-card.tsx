import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Module, UserProgress } from "@shared/schema";

interface ModuleCardProps {
  module: Module;
  progress?: UserProgress;
  onClick?: () => void;
}

export default function ModuleCard({ module, progress, onClick }: ModuleCardProps) {
  const progressPercentage = progress ? Math.round((progress.completedLessons / progress.totalLessons) * 100) : 0;
  const stars = progress ? Math.floor(progress.score / 33.33) : 0; // 0-3 stars
  
  const getColorClasses = (color: string) => {
    const colorMap: { [key: string]: string } = {
      red: "bg-red-100 dark:bg-red-900/30 text-red-600",
      green: "bg-green-100 dark:bg-green-900/30 text-green-600",
      blue: "bg-blue-100 dark:bg-blue-900/30 text-blue-600",
      purple: "bg-purple-100 dark:bg-purple-900/30 text-purple-600",
      orange: "bg-orange-100 dark:bg-orange-900/30 text-orange-600",
      teal: "bg-teal-100 dark:bg-teal-900/30 text-teal-600",
      gray: "bg-gray-100 dark:bg-gray-700 text-gray-600",
      indigo: "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600",
      pink: "bg-pink-100 dark:bg-pink-900/30 text-pink-600",
      yellow: "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600",
    };
    return colorMap[color] || colorMap.gray;
  };

  return (
    <Card 
      className="card-hover cursor-pointer border border-gray-200 dark:border-gray-700"
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${getColorClasses(module.color)}`}>
          {module.icon.startsWith('/') ? (
            <img src={module.icon} alt={module.name} className="w-8 h-8" />
          ) : (
            <i className={`${module.icon} text-xl`}></i>
          )}
        </div>
        
        <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
          {module.name}
        </h4>
        
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          {module.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex -space-x-1">
              {[1, 2, 3].map((starIndex) => (
                <div
                  key={starIndex}
                  className={`w-6 h-6 rounded-full flex items-center justify-center border-2 border-white ${
                    starIndex <= stars
                      ? "bg-yellow-400"
                      : "bg-gray-300 dark:bg-gray-600"
                  }`}
                >
                  <Star 
                    className={`w-3 h-3 ${
                      starIndex <= stars 
                        ? "text-white fill-white" 
                        : "text-gray-500"
                    }`} 
                  />
                </div>
              ))}
            </div>
          </div>
          
          <Badge variant="secondary" className="text-xs">
            {progressPercentage}% completo
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
